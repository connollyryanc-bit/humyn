# humyn

People intelligence SaaS: helps leaders see who they have, how they work, and who works best together. Multi-company from day one: every table has `org_id` and row-level security. v1 is **humyn Teams** (see `docs/spec.md`).

## Read first
- `docs/spec.md` — scope, architecture, data model, compliance, build phases. The source of truth.
- `design-system/README.md` — brand rules. `design-system/tokens.json` / `tokens.css` — every colour, size, radius. `design-system/components/*/README.md` + `preview.html` — each component. `design-system/gallery.html` (open in a browser) and `gallery.png` — how they look.
- `mockups/README.md` — the approved screens to match.
- `docs/questionnaire.md` — the Pulse Questionnaire items and scoring (Phase 3).

## Stack
Next.js (App Router), TypeScript strict, Supabase (EU region) for Postgres, auth and storage, Anthropic API server-side only, Vercel (EU). Manrope via `next/font/google`.

## Rules
- Build only from these files. Never read, copy or migrate code from any older Humyn repository.
- Style only through `components/ui` and `styles/tokens.css`. No hex values, inline colours or one-off font sizes in pages (a lint rule enforces this).
- A new UI pattern becomes a component in `components/ui` first, matching the design system's names and props.
- Restraint: white page, 120px between sections, one hero moment and one primary action per screen, content unboxed with hairline dividers.
- Energies: Driver, Energizer, Harmoniser, Analyst (wheel adjectives: Driving, Energizing, Harmonising, Analytical). Never colour names in the UI, never Insights Discovery terms.
- No traffic-light colours. Status = navy, outline, brand gradient, always with a word. Energy colours only ever mean personality.
- Profiles start as drafts; only the person approves. Only approved profiles are shown to others. The questionnaire result always overrides an AI draft.
- Never infer emotion, mood or health. Never recommend who to fire or rank people by personality. Scenario screens show impact only and say "People decide."
- Log every profile view by someone else, every export and every AI generation to `audit_log`.
- AI calls are server-side only; keys never reach the browser.
- Sample data is invented and labelled as sample.
- Write plain-language UI copy: short sentences, "you", lowercase "humyn".

## Working style
- Work phase by phase (spec § Build phases). Stop at the end of each phase, deploy a preview, and show the result before starting the next.
- Keep the code clean and well named so another developer can take it over.
