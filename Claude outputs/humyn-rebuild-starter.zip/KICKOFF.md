# Kickoff prompt for Claude Code

Open Claude Code in this folder and paste:

```
We are building humyn from scratch: a multi-company people intelligence SaaS. This folder is a new repository. Do not look for, read or copy any other Humyn codebase.

Read CLAUDE.md, docs/spec.md, design-system/README.md, design-system/tokens.json, every design-system/components/*/README.md and preview.html, and mockups/README.md. Look at design-system/gallery.png.

Then do Phase 1 only (Foundations):
- Next.js (App Router), TypeScript strict, Supabase client set up for an EU project (I will give you the keys in .env.local).
- Turn design-system/tokens.json into styles/tokens.css (light and dark), matching design-system/tokens.css.
- Load Manrope with next/font/google.
- Build every design system component in components/ui/ as typed React components with the same names and props as design-system/components/index.d.ts, matching the previews exactly.
- Add a /design page that shows every component in light and dark, like design-system/gallery.html.
- Add a lint rule that fails on hex colours outside styles/tokens.css.

Leave design-system/, mockups/, docs/ and brand/ untouched; they are the reference. Stop after Phase 1 and show me the /design page.
```

After Phase 1, continue one phase at a time with: "Do Phase 2 from docs/spec.md. Stop at the end and show me." Phases 3–5 should match the screens in `mockups/`.
