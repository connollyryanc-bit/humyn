# humyn — rebuild starter

Everything Claude Code needs to rebuild humyn from scratch, as local files.

1. Create a new, empty folder and unzip this into it (not the old Humyn repo).
2. Create a new GitHub repo, a Vercel project, a Supabase project in an EU region and an Anthropic API key, all under your own accounts.
3. Open Claude Code in the folder and paste the prompt in `KICKOFF.md`.

| Folder | What |
| --- | --- |
| `CLAUDE.md` | Rules Claude Code follows on every task |
| `KICKOFF.md` | The first prompt to paste |
| `docs/spec.md` | Rebuild spec: scope, architecture, data model, compliance, phases |
| `docs/questionnaire.md` | Pulse Questionnaire v0.2: items, scoring, validation |
| `docs/vision-and-business-plan.md` | Vision, business plan, legal notes (context only) |
| `design-system/` | Tokens, brand rules, 24 components with guidelines and previews, `gallery.html` / `gallery.png` |
| `mockups/` | Approved screens: navigation, overview, people, profile |
| `brand/humyn-app-icon.png` | The logo (full colour, app icon) |

Not included yet: mockups for the Team builder, Capacity, Scenarios, sign-in/onboarding and consent screens; small-size and single-colour logos; an icon set.
