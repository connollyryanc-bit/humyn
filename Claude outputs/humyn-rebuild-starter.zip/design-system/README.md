humyn is people intelligence for the AI era: it helps leaders see who they have, how those people work, and who works best together. The look is bold, modern, sophisticated and a little playful: large, light, tightly tracked type; the deep navy of the logo; soft glowing auras in the logo's four wing colours; frosted glass floating above them; and those same four colours as the language of personality. Three modules share one system: **humyn Teams** (people, capacity, executive), **humyn Reach** (sales) and **humyn Careers** (job seekers).

## Content fundamentals

- Write the name in lowercase everywhere: humyn, humyn Teams, humyn Reach.
- Speak plainly and warmly, like a good people manager: short sentences, active voice, no jargon. "Three people come off the bench on Monday", not "Bench availability event detected".
- Big headlines can have personality ("Know who you have."); everything else stays clear and specific.
- Address the user as "you". A person is never "a resource" or "headcount" in the UI.
- Name the energies by archetype only: **Driver**, **Energizer**, **Harmoniser**, **Analyst**. Never colour names, and never Insights Discovery vocabulary.
- Personality insight is advice, not a verdict: "tends to", "usually", "may". Mark anything AI-inferred with a Pill of tone `ai` reading "AI inferred".
- Every figure that drives a decision says what it is compared with.
- No emoji, no exclamation marks.

## Visual foundations

**Restraint first.** White space is the default, not the leftover. Each screen gets ONE hero moment (one aura, at most) and ONE primary action. Most content sits straight on the white page, separated by `space-30` between sections and hairline `line` dividers, not boxes. Use a card only for a thing you can pick up (a person, a scenario). One headline and one supporting line per section; no eyebrow, subline and footnote all at once. Colour appears only where it carries meaning.

**Colour.** Three languages, never mixed:
1. *Chrome.* `surface` (white) page, `surface-raised` cards, `surface-sunken` tracks and rails, `line` hairlines, `ink` / `ink-muted` / `ink-faint` text. `night`, the logo's navy, is the bold move: the nav, hero headers, the primary button, the active tab and one featured card or stat per screen, with `on-night` text.
2. *Signature.* The logo's gradient, used sparingly. `gradient-brand` sits behind white text (the brand button, AI badges); `gradient-logo` is decoration only (the y in the wordmark, the AI outline, the hero glow). At most two gradient moments per screen.
3. *Energies.* The four wings of the logo: `driver` hot pink, `energizer` apricot, `harmoniser` lavender, `analyst` cobalt, each with `-soft` grounds and `-ink` text partners. They appear only where they mean a person's energy. Energizer apricot is light, so it always sits on a track or beside its label.

Status never uses colour of its own, and there are no traffic-light greens, ambers or reds anywhere. Steady states are quiet (`surface-sunken`, `ink`), states to watch are an outline or solid `night`, and anything that needs attention (at risk, high risk) takes `gradient-brand`, the one attention signal in the system. Energy colours never mean good or bad. Every status carries its word.

**Type.** Manrope only (Google Fonts, free, SIL Open Font License). Confidence comes from size, not weight: display styles at 500 with tight negative tracking, `hero` 64, `title` 40, `numeral` 56, and `heading` 22 at 600. Headlines are two-tone with `Heading`: the statement in `ink`, the turn on a second line in `ink-faint` ("A living profile, / not a one-off survey."). Text at 500–700: `subheading` 17, `body` 15, `body-sm` 13, `caption` 12, `label` 11 uppercase with 0.1em tracking, usually inside a `Tag` pill. Nothing below 11px. Figures that line up use tabular numerals.

**Shape and space.** Generous and rounded. Buttons, tabs, badges, pills and avatars are full pills (`radius-pill`); cards are `radius-lg`; hero bands and night cards `radius-xl`; inner tiles `radius-md`. Spacing on a 4px base from `space-1` to `space-30`: sections are `space-30` apart on desktop (`space-24` on smaller screens), a headline sits `space-8` to `space-16` above its content, cards pad `space-6`, hero bands pad `space-12` or more. Content is at most `page-max` wide, the nav is `nav-height`, drawers are `drawer-width`.

**Auras and glass.** The signature surface is an aura: `night` with blurred glows of `analyst`, `harmoniser`, `driver` and `energizer` (class `hy-aura`), or the warm version of pink and apricot (`hy-aura-warm`). Use it for the hero, one bento tile and topic cards; never behind dense data. Over an aura, panels are frosted `glass` with a `glass-line` edge and backdrop blur; navigation and tags over an aura use `glass-dark`. Text on an aura is `on-night`.

**Depth.** Cards are a `line` border on white, no shadow; drawers, menus and dialogs float on `shadow-float` over `scrim`; only the brand button glows (`shadow-glow`).

**Motion.** Small and quick: buttons lift 1px on hover, colours and backgrounds ease over 0.15s. No bouncing, no looping animation; respect reduced motion.

**States.** Hover lifts or darkens the border to `ink`; focus is a 2.5px solid `ink` ring with a 3px offset (`on-night` on night bands); selected is `night`; disabled is 45% opacity.

**Themes.** Light by default, dark through the same tokens. Every text token's note names the grounds it reads on, and every pair meets 4.5:1 in both themes. Hot pink and lavender sit close in lightness, so energy is always labelled, never shown by colour alone.

**Data visualisation.** Energies always appear in the order Driver, Energizer, Harmoniser, Analyst, on `surface-sunken` tracks 10px tall. `gradient-energy` (the four energies as one ring) is for team balance and loading states only. Labels never overlap; on narrow charts use initials plus a legend.

## Logo

`assets/Logos/humyn-app-icon.png` is the app icon: two faces in profile forming a butterfly (change) and an H, on navy. Use it for the app icon, browser tab, Chrome extension and sign-in screen, 48px and up, beside the `Wordmark`. Small-size (16–32px) and single-colour versions are still to be drawn; until then use the wordmark alone at small sizes. Its four wing colours are the four energies, so a version with each wing in one energy colour would tie the mark to the product.

## Iconography

The components draw five glyphs of their own, 16px with a 2px round stroke in `currentColor`: arrow up-right (round buttons, linked tiles), chevron (SplitButton), send (assistant), check (checklists) and the four-point spark in the energy colours (AI). No full icon set is chosen yet; when one is, pick a rounded outline set with a 2px stroke to match. No emoji.

## Components

Build every screen from these instead of styling elements one by one: `Wordmark`, `Button`, `Card`, `SectionLabel`, `PageHeader`, `Tabs`, `Pill`, `EnergyBadge`, `StatusBadge`, `RiskPill`, `UtilPill`, `Avatar`, `EnergyBars`, `Stat`, and the composed `PersonCard`. Page-level patterns: `AuraHero`, `AssistantCard`, `SplitButton`, `Tag`, `Heading`, `BentoStat`, `PhaseCards`, `TopicCard`, `FAQ`. They live in `components/bundle.js` as `window.Humyn`, expect React 18, and are styled by `components/bundle.css` through the tokens. A new pattern becomes a component here first, then gets used in the app.
