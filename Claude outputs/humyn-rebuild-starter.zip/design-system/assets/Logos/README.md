# Logos

- `humyn-app-icon.png`: the full-colour app icon (1254 × 1254 PNG), the butterfly of two facing profiles on navy. App icon, browser tab, extension and sign-in screen; 48px and up. Full colour only; no single-colour version exists yet.
