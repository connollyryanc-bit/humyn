# AssistantCard

The floating "Ask humyn" panel: frosted glass, the assistant's gradient mark, a question in large type, suggestion chips, an input, and the next step.

Provide `question`; optional `hint`, `suggestions` (three, phrased as the user would ask), `placeholder` (a realistic example question), `next` and `inputId`. It floats over an aura or over content, never inline in a dense table.
