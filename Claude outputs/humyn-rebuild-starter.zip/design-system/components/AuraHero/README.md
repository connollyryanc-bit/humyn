# AuraHero

The hero band: a night canvas glowing with the four energy colours, a frosted pill nav, a glass eyebrow tag, a two-tone hero headline, the SplitButton, social proof, and the assistant floating to the right.

Provide `title`, `mutedLine`; optional `links`, `navCta`, `eyebrow`, `subtitle`, `cta`, `proof` and `assistant` (AssistantCard props). Use on module landing pages, the executive dashboard top and marketing pages. One per page.
