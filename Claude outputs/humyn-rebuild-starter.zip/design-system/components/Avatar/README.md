# Avatar

A person's initials inside a ring split between their primary energy (about 60%) and secondary energy.

Provide `initials`, `energy` and `secondary`; optional `size` (default 44; 32 in tables, 72 on profile headers) and `name` for the tooltip. Replace with a photo only when the person has added one themselves.
