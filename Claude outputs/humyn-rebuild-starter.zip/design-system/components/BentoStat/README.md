# BentoStat

A bento tile with one big figure and a short caption, for dashboard tops and landing pages. Tones: `light` (surface-sunken), `warm` (the logo's warm aura), `cool` (the energy aura on night), `night`.

Provide `value`, `caption`; optional `sup` (a raised + or %), `tone`, and `badge` for an arrow when the tile links somewhere. Mix tones in a bento grid: one aura tile per group at most.
