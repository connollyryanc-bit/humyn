# Button

Buttons trigger one action, labelled with a verb that says exactly what happens.

All buttons are pills in Manrope 700.

- `primary` (night fill): the one main action on a screen, e.g. "Full profile", "Build team".
- `secondary` (default): everything else.
- `ghost`: low-emphasis actions inside cards and toolbars.
- `brand` (`gradient-brand` with `shadow-glow`): AI and Pulse actions only ("Generate profile", "Rewrite for Analyst"). At most one per screen.
- `on-night`: the main action on a night band.

Provide `children` (the label) and `onClick`; `size="sm"` inside dense cards. Don't put two primary buttons side by side.
