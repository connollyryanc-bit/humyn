# Card

The surface for grouping content: `surface-raised`, `line` border, `shadow-card`, `radius-lg`, `space-6` padding. `tone="night"` makes a featured card on the logo's navy at `radius-xl`; use one per screen at most.

Provide `children`. Use `flush` for tables and lists that run edge to edge. Lay cards in a grid with `space-4` gaps. Don't nest cards inside cards; use a `SectionLabel` and a divider instead. Don't add coloured top or side bars to show energy; use an `Avatar` or `EnergyBadge`.
