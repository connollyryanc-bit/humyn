# EnergyBadge

Shows a person's energy with a dot and the archetype name: Driver, Energizer, Harmoniser or Analyst.

Provide `energy` (archetype or the data model's colour key). Optional `label` for a wheel position, e.g. "Energizing Driver" on the primary energy. Never write the colour name (Red, Yellow) in the UI, and never use Insights Discovery terms.
