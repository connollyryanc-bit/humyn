# EnergyBars

Compact energy profile: the four energies in fixed order (Driver, Energizer, Harmoniser, Analyst) with bars and percentages.

Provide `scores` keyed by archetype or colour. Order never changes so profiles can be compared at a glance. For the full profile use EnergyRing, EnergyDynamics and EnergySpider (to be ported from the app).
