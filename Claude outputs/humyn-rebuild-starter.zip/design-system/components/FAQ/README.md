# FAQ

Questions and answers with hairline dividers and a round plus that turns and fills when open.

Provide `items` (`q`, `a`); optional `defaultOpen` (index, or -1 for none). Write questions the way a sceptical HR director would ask them, and answer in two or three plain sentences.
