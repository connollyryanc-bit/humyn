# Heading

Two-tone headline: the statement in `ink`, the turn in `ink-faint` on a second line. Manrope 500, large, tracked tight.

Provide `children` (first line) and `muted` (second line); `size="hero"` for hero bands, default `title` for sections. Keep each line under about 30 characters; the second line should twist or qualify the first.
