# PageHeader

The top of every page: optional eyebrow (module and scope), the title in Manrope 800, a one-sentence subtitle, and actions on the right. `hero` turns it into a night band with a soft glow; for full landing tops use `AuraHero`.

Provide `title`; optionally `eyebrow` (e.g. "Pulse · Nordics"), `subtitle` (what this page helps you do, under 60 characters ideally) and `actions` (buttons or tabs). One per page.
