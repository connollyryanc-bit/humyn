# PersonCard

The person card from the People directory, built only from the other components: Avatar with energy ring, name and role, EnergyBadge with wheel position, StatusBadge, bio, EnergyBars, UtilPill, two figures and two actions.

Provide `person` (name, initials, role, location, primary, secondary, wheelPosition, available, bio, scores, utilisation, clients, revenue). Lay out in a grid with a 300px minimum column. Keep the bio to two lines.
