# PhaseCards

A row of phase cards for programmes, onboarding and rollouts: when, title, a line of text, a checklist, and progress on the active phase, which turns `night`.

Provide `phases` (`when`, `title`, `text`, `active`, `progress`, `items` with `done`). Three or four phases; exactly one active.
