# Pill

Outlined tag for skills, capabilities and filters. Carries no meaning through colour.

Provide `children`. `tone="ai"` gives it a `gradient-logo` outline and spark: it marks AI-generated or Pulse-inferred content only. For energy, status or risk use the dedicated badges, never a Pill.
