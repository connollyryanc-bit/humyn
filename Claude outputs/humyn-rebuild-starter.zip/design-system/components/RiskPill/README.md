# RiskPill

Flight risk or delivery risk on capacity and executive views: High, Medium, Watch, Low.

Provide `level`. Escalates through the brand, never through traffic-light colours: low is quiet `surface-sunken`, watch is an outline, medium is solid `night`, high is `gradient-brand`, the one attention signal in the system. Always shows the word.
