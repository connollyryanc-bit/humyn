# SectionLabel

Small uppercase label that names a block of content: 11px, Manrope 800, 0.12em tracking, `ink-faint` (or `on-night-muted` on night).

Provide the label text in sentence form; the component uppercases it. Use one per block, never as a heading for a whole page.
