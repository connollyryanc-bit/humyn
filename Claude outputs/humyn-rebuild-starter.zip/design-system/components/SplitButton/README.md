# SplitButton

The signature call to action: a night pill with a short lead (price, duration, proof) and a white pill holding the action.

Provide `lead` and `children` (the verb), plus `onClick`. One per page, for the action that matters most. Everywhere else use `Button`.
