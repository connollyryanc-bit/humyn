# Stat

One headline figure, unboxed: a hairline on its left, then the label, the number and a line of context. Put three or four in a row straight on the page. `tone="night"` for the single most important figure on a dashboard.

Provide `label`, `value` (formatted: €1.4M, 92%) and optional `note` saying what the number is compared with. Use three to five in a row; don't make every number on a page a Stat.
