# StatusBadge

Availability of a person: Available now, Available soon, Allocated. Outlined, with a dot that empties as availability drops: solid `ink` for now, a ring for soon, faint for allocated. No energy colours, so it never reads as personality.

Provide `status`: `now`, `soon` or `allocated`. The word always shows; colour is never the only signal.
