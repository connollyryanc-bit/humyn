# Tabs

Switches between views of the same object (a profile's Overview, Personality, How to engage). Plain text tabs on a hairline: the active tab is `ink` with a 2px `ink` underline, the rest `ink-faint`.

Provide `items` (`value`, `label`, optional `count`), and `value` + `onChange` to control it. Keep labels to one or two words so they never wrap; it scrolls sideways on phones. Use the top nav, not tabs, to move between modules.
