# Tag

A small uppercase eyebrow in a pill, above headlines and on cards: "PEOPLE INTELLIGENCE", "WEEKS 1–2".

Provide `children`. Use `glass` over an aura or photo. One per block; it labels, it never acts.
