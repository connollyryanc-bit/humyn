# TopicCard

A glowing card that opens a topic, tinted by an energy's aura: the energy guides, a market, a module. Glass eyebrow, title, a line of text and a round arrow button that turns on hover.

Provide `title`; optional `energy` (sets the glow), `eyebrow` and `text`. Lay them three or four across.
