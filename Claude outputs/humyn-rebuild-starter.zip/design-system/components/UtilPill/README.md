# UtilPill

Utilisation against target, labelled: the label, the percentage, the verdict in words, a bar and a tick at the target.

Provide `value` (0–100); optional `target` (default 80) and `label`. Verdicts: at or above target = On target (`ink` bar), up to 15 points below = Below target (`ink-faint` bar), further = At risk (`gradient-brand` bar and word). Never show the bar without the number and word.
