# Wordmark

The humyn wordmark set in type: lowercase Manrope 800, tracked tight, with the y filled by `gradient-logo`.

Use it in the nav (30px) and on sign-in and hero screens. On a `night` band pass `onNight`. Always lowercase; never outline, stretch or recolour it; the gradient lives only in the y. Provide: optional `size` in px.
