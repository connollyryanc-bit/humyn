/* @ds-bundle: {"format":4,"namespace":"Humyn","components":[{"name":"Wordmark"},{"name":"Button"},{"name":"Card"},{"name":"SectionLabel"},{"name":"PageHeader"},{"name":"Tabs"},{"name":"Pill"},{"name":"EnergyBadge"},{"name":"StatusBadge"},{"name":"RiskPill"},{"name":"UtilPill"},{"name":"Avatar"},{"name":"EnergyBars"},{"name":"Stat"},{"name":"PersonCard"},{"name":"Tag"},{"name":"Heading"},{"name":"SplitButton"},{"name":"AssistantCard"},{"name":"AuraHero"},{"name":"BentoStat"},{"name":"PhaseCards"},{"name":"TopicCard"},{"name":"FAQ"}]} */
(function () {
  var React = window.React, h = React.createElement;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(" "); }
  var ENERGY = {
    driver: { label: "Driver", key: "driver" }, energizer: { label: "Energizer", key: "energizer" },
    harmoniser: { label: "Harmoniser", key: "harmoniser" }, analyst: { label: "Analyst", key: "analyst" },
    supporter: { label: "Harmoniser", key: "harmoniser" },
    red: { label: "Driver", key: "driver" }, yellow: { label: "Energizer", key: "energizer" },
    green: { label: "Harmoniser", key: "harmoniser" }, blue: { label: "Analyst", key: "analyst" }
  };
  function en(e) { return ENERGY[e] || ENERGY.driver; }

  function Wordmark(p) {
    return h("span", { className: cx("hy-wordmark", p.onNight && "hy-wordmark-night", p.className), style: p.size ? { fontSize: p.size } : null, "aria-label": "humyn" },
      "hum", h("span", { className: "hy-wordmark-y" }, "y"), "n");
  }
  function Button(p) {
    var variant = p.variant || "secondary", size = p.size || "md";
    var rest = Object.assign({}, p); delete rest.variant; delete rest.size; delete rest.className;
    return h("button", Object.assign({ type: "button" }, rest, { className: cx("hy-btn", "hy-btn-" + variant, "hy-btn-" + size, p.className) }), p.children);
  }
  function Card(p) {
    return h(p.as || "div", { className: cx("hy-card", p.tone === "night" && "hy-card-night", p.flush && "hy-card-flush", p.className) }, p.children);
  }
  function SectionLabel(p) { return h("div", { className: "hy-label" }, p.children); }
  function PageHeader(p) {
    return h("header", { className: cx("hy-pagehead", p.hero && "hy-pagehead-hero") },
      h("div", { className: "hy-pagehead-text" },
        p.eyebrow ? h("div", { className: "hy-label" }, p.eyebrow) : null,
        h("h1", { className: p.hero ? "hy-hero" : "hy-title" }, p.title),
        p.subtitle ? h("p", { className: "hy-pagehead-sub" }, p.subtitle) : null),
      p.actions ? h("div", { className: "hy-pagehead-actions" }, p.actions) : null);
  }
  function Tabs(p) {
    var st = React.useState(p.defaultValue || (p.items[0] && p.items[0].value));
    var value = p.value !== undefined ? p.value : st[0];
    return h("div", { className: "hy-tabs", role: "tablist" }, p.items.map(function (it) {
      var on = it.value === value;
      return h("button", { key: it.value, type: "button", role: "tab", "aria-selected": on, className: cx("hy-tab", on && "hy-tab-on"),
        onClick: function () { st[1](it.value); if (p.onChange) p.onChange(it.value); } }, it.label,
        it.count != null ? h("span", { className: "hy-tab-count" }, it.count) : null);
    }));
  }
  function Pill(p) {
    return h("span", { className: cx("hy-pill", p.tone === "ai" && "hy-pill-ai") }, p.tone === "ai" ? h("i", { className: "hy-spark" }) : null, p.children);
  }
  function EnergyBadge(p) {
    var e = en(p.energy);
    return h("span", { className: "hy-badge hy-badge-" + e.key }, h("i", { className: "hy-dot hy-dot-" + e.key }), p.label || e.label);
  }
  var STATUS = { now: ["good", "Available now"], soon: ["warn", "Available soon"], allocated: ["neutral", "Allocated"] };
  function StatusBadge(p) {
    var s = STATUS[p.status] || STATUS.now;
    return h("span", { className: "hy-badge hy-badge-outline" }, h("i", { className: "hy-dot hy-dot-" + s[0] }), s[1]);
  }
  var RISK = { high: ["bad", "High risk"], medium: ["warn", "Medium risk"], watch: ["outline", "Watch"], low: ["good", "Low risk"] };
  function RiskPill(p) {
    var r = RISK[p.level] || RISK.watch;
    return h("span", { className: "hy-badge hy-badge-" + r[0] }, h("i", { className: "hy-dot hy-dot-" + (r[0] === "outline" ? "warn" : r[0]) }), r[1]);
  }
  function utilTone(v, t) { return v >= t ? ["good", "On target"] : v >= t - 15 ? ["warn", "Below target"] : ["bad", "At risk"]; }
  function UtilPill(p) {
    var t = p.target || 80, tone = utilTone(p.value, t), w = Math.max(0, Math.min(100, p.value));
    return h("div", { className: "hy-util" },
      h("div", { className: "hy-util-head" }, h("span", { className: "hy-util-label" }, p.label || "Utilisation"),
        h("span", { className: "hy-util-val hy-ink-" + tone[0] }, p.value + "%", h("span", { className: "hy-util-word" }, " · " + tone[1]))),
      h("div", { className: "hy-util-track", role: "meter", "aria-valuenow": p.value, "aria-valuemin": 0, "aria-valuemax": 100, "aria-label": (p.label || "Utilisation") + " " + p.value + "%" },
        h("div", { className: "hy-util-fill hy-fill-" + tone[0], style: { width: w + "%" } }),
        h("div", { className: "hy-util-target", style: { left: t + "%" }, title: "Target " + t + "%" })));
  }
  function Avatar(p) {
    var a = en(p.energy), b = en(p.secondary || p.energy), size = p.size || 44;
    var style = { width: size, height: size, fontSize: Math.round(size * 0.34), "--a1": "var(--" + a.key + ")", "--a2": "var(--" + b.key + ")", "--a1p": p.secondary ? "62%" : "100%" };
    return h("span", { className: "hy-avatar", style: style, title: p.name }, p.initials);
  }
  var ORDER = ["driver", "energizer", "harmoniser", "analyst"], ALT = { driver: "red", energizer: "yellow", harmoniser: "green", analyst: "blue" };
  function score(sc, k) { return sc[k] != null ? sc[k] : (k === "harmoniser" && sc.supporter != null ? sc.supporter : (sc[ALT[k]] || 0)); }
  function EnergyBars(p) {
    var sc = p.scores || {};
    return h("div", { className: "hy-ebars" }, ORDER.map(function (k) {
      var v = score(sc, k);
      return h("div", { key: k, className: "hy-ebar" },
        h("span", { className: "hy-ebar-name" }, h("i", { className: "hy-dot hy-dot-" + k }), ENERGY[k].label),
        h("span", { className: "hy-ebar-track" }, h("span", { className: "hy-ebar-fill hy-fill-" + k, style: { width: v + "%" } })),
        h("span", { className: "hy-ebar-val" }, v + "%"));
    }));
  }
  function Stat(p) {
    return h("div", { className: cx("hy-stat", p.tone === "night" && "hy-stat-night") }, h("div", { className: "hy-label" }, p.label),
      h("div", { className: "hy-numeral" }, p.value), p.note ? h("div", { className: "hy-stat-note" }, p.note) : null);
  }
  function PersonCard(p) {
    var x = p.person;
    return h("div", { className: "hy-card hy-person" },
      h("div", { className: "hy-person-head" },
        h(Avatar, { initials: x.initials, energy: x.primary, secondary: x.secondary, size: 52, name: x.name }),
        h("div", null, h("div", { className: "hy-person-name" }, x.name), h("div", { className: "hy-person-role" }, x.role + " · " + x.location))),
      h("div", { className: "hy-person-tags" }, h(EnergyBadge, { energy: x.primary, label: x.wheelPosition }), h(StatusBadge, { status: x.available })),
      h("p", { className: "hy-person-bio" }, x.bio),
      h(EnergyBars, { scores: x.scores }),
      h(UtilPill, { value: x.utilisation }),
      h("div", { className: "hy-person-figs" },
        h("div", { className: "hy-person-fig" }, h("span", null, "Clients"), h("b", null, x.clients)),
        h("div", { className: "hy-person-fig" }, h("span", null, "Revenue"), h("b", null, x.revenue))),
      h("div", { className: "hy-person-foot" }, h(Button, { size: "sm" }, "Quick view"), h(Button, { size: "sm", variant: "primary" }, "Full profile")));
  }
  window.Humyn = Object.assign(window.Humyn || {}, { Wordmark: Wordmark, Button: Button, Card: Card, SectionLabel: SectionLabel, PageHeader: PageHeader, Tabs: Tabs, Pill: Pill, EnergyBadge: EnergyBadge, StatusBadge: StatusBadge, RiskPill: RiskPill, UtilPill: UtilPill, Avatar: Avatar, EnergyBars: EnergyBars, Stat: Stat, PersonCard: PersonCard });

  function svg(path, extra) { return h("svg", Object.assign({ viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", className: "hy-ico", "aria-hidden": true }, extra || {}), path); }
  var I = {
    arrowUR: function () { return svg(h("path", { d: "M5 11L11 5M6 5h5v5" })); },
    chevron: function () { return svg(h("path", { d: "M6 4l4 4-4 4" })); },
    send: function () { return svg(h("path", { d: "M8 13V3M4 7l4-4 4 4" })); },
    check: function () { return svg(h("path", { d: "M3.5 8.5l3 3 6-7" }), { strokeWidth: 2.5 }); },
    spark: function () { return h("svg", { viewBox: "0 0 16 16", className: "hy-ico", "aria-hidden": true }, h("defs", null, h("linearGradient", { id: "hysg", x1: 0, y1: 0, x2: 1, y2: 1 }, h("stop", { offset: 0, stopColor: "var(--analyst)" }), h("stop", { offset: .5, stopColor: "var(--harmoniser)" }), h("stop", { offset: 1, stopColor: "var(--energizer)" }))), h("path", { fill: "url(#hysg)", d: "M8 0c.6 4.3 3.7 7.4 8 8-4.3.6-7.4 3.7-8 8-.6-4.3-3.7-7.4-8-8 4.3-.6 7.4-3.7 8-8z" })); }
  };
  function Tag(p) { return h("span", { className: cx("hy-tag", p.glass && "hy-tag-glass") }, p.children); }
  function Heading(p) {
    var El = p.as || "h2";
    return h(El, { className: p.size === "hero" ? "hy-hero" : "hy-title" }, p.children, p.muted ? h("span", { className: "hy-muted-line" }, p.muted) : null);
  }
  function SplitButton(p) {
    return h("button", { type: "button", className: "hy-split", onClick: p.onClick }, p.lead, h("span", { className: "hy-split-go" }, p.children, I.chevron()));
  }
  function AssistantCard(p) {
    return h("div", { className: "hy-glass hy-assist" },
      h("div", { className: "hy-assist-head" }, h("i", { className: "hy-assist-mark" }),
        h("div", { className: "hy-assist-who" }, p.name || "Ask humyn", h("span", null, p.role || "People intelligence assistant")),
        h(Pill, { tone: "ai" }, "AI")),
      h("p", { className: "hy-assist-q" }, I.spark(), p.question),
      p.hint ? h("p", { className: "hy-assist-hint" }, p.hint) : null,
      h("div", { className: "hy-chips" }, (p.suggestions || []).map(function (c) { return h("button", { key: c, type: "button", className: "hy-chip" }, c); })),
      h("label", { className: "hy-ask" }, h("input", { id: p.inputId || "hy-ask", placeholder: p.placeholder || "Ask about your people", "aria-label": "Ask humyn" }), h("button", { type: "button", "aria-label": "Send" }, I.send())),
      p.next ? h("div", { className: "hy-assist-foot" }, h("span", null, "Next step"), h("b", null, p.next)) : null);
  }
  function AuraHero(p) {
    return h("section", { className: "hy-aura hy-auhero hy-on-aura" },
      h("nav", { className: "hy-auhero-nav" },
        h("div", { className: "hy-auhero-links" }, (p.links || []).map(function (l) { return h("a", { key: l, href: "#" }, l); })),
        h(Wordmark, { onNight: true, size: 24 }),
        h("div", { className: "hy-auhero-right" }, h("span", null, "Sign in"), h("span", { className: "hy-auhero-cta" }, p.navCta || "Get started"))),
      h("div", { className: "hy-auhero-body" },
        h("div", { className: "hy-auhero-copy" },
          p.eyebrow ? h(Tag, { glass: true }, p.eyebrow) : null,
          h(Heading, { as: "h1", size: "hero", muted: p.mutedLine }, p.title),
          p.subtitle ? h("p", { className: "hy-auhero-sub" }, p.subtitle) : null,
          p.cta ? h("div", null, h(SplitButton, { lead: p.cta.lead }, p.cta.label)) : null,
          p.proof ? h("div", { className: "hy-proof" }, h("div", { className: "hy-proof-faces" }, p.proof.people.map(function (x) { return h(Avatar, { key: x[0], initials: x[0], energy: x[1], secondary: x[2], size: 30 }); })), h("span", null, p.proof.text)) : null),
        p.assistant ? h(AssistantCard, p.assistant) : null));
  }
  function BentoStat(p) {
    var tone = p.tone || "light";
    return h("div", { className: cx("hy-bento", tone === "warm" && "hy-aura hy-aura-warm", tone === "cool" && "hy-aura", tone === "night" && "hy-night") },
      p.badge ? h("span", { className: "hy-bento-badge" }, I.arrowUR()) : null,
      h("div", { className: "hy-numeral" }, p.value, p.sup ? h("sup", null, p.sup) : null),
      h("div", { className: "hy-bento-cap" }, p.caption));
  }
  function PhaseCards(p) {
    return h("div", { className: "hy-phases" }, p.phases.map(function (ph, i) {
      return h("div", { key: i, className: cx("hy-phase", ph.active && "hy-phase-active") },
        h("div", { className: "hy-label" }, ph.when),
        h("h3", { className: "hy-phase-title" }, ph.title),
        ph.text ? h("p", { className: "hy-phase-text" }, ph.text) : null,
        ph.progress ? h("div", { className: "hy-phase-prog" }, h("div", { className: "hy-phase-track" }, h("i", { style: { width: ph.progress.value + "%" } })), ph.progress.label) : null,
        h("div", { className: "hy-checks" }, (ph.items || []).map(function (it) {
          return h("div", { key: it.label, className: cx("hy-check", it.done && "hy-check-done") }, h("span", { className: "hy-check-box" }, it.done ? I.check() : null), it.label);
        })));
    }));
  }
  function TopicCard(p) {
    var e = en(p.energy || "analyst");
    return h("div", { className: "hy-aura hy-topic hy-topic-" + e.key },
      h(Tag, { glass: true }, p.eyebrow || e.label),
      h("div", { className: "hy-topic-foot" },
        h("div", null, h("h3", { className: "hy-topic-title" }, p.title), p.text ? h("p", { className: "hy-topic-text" }, p.text) : null),
        h("button", { type: "button", className: "hy-roundbtn", "aria-label": "Open " + p.title }, I.arrowUR())));
  }
  function FAQ(p) {
    var st = React.useState(p.defaultOpen != null ? p.defaultOpen : 0);
    return h("div", { className: "hy-faq" }, p.items.map(function (it, i) {
      var open = st[0] === i;
      return h("div", { key: i, className: cx("hy-faq-item", open && "hy-faq-open") },
        h("button", { type: "button", className: "hy-faq-q", "aria-expanded": open, onClick: function () { st[1](open ? -1 : i); } }, it.q, h("span", { className: "hy-faq-sign", "aria-hidden": true }, "+")),
        open ? h("p", { className: "hy-faq-a" }, it.a) : null);
    }));
  }
  window.Humyn = Object.assign(window.Humyn || {}, { Tag: Tag, Heading: Heading, SplitButton: SplitButton, AssistantCard: AssistantCard, AuraHero: AuraHero, BentoStat: BentoStat, PhaseCards: PhaseCards, TopicCard: TopicCard, FAQ: FAQ });
})();
