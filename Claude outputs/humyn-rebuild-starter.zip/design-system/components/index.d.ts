import type * as React from 'react';
/** Energy keys. The colour keys from the data model (red/yellow/green/blue) are accepted and mapped. */
export type Energy = 'driver' | 'energizer' | 'harmoniser' | 'analyst' | 'supporter' | 'red' | 'yellow' | 'green' | 'blue';
export interface WordmarkProps { size?: number; onNight?: boolean; className?: string }
export declare function Wordmark(props: WordmarkProps): React.ReactElement;
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> { variant?: 'primary' | 'secondary' | 'ghost' | 'brand'; size?: 'md' | 'sm' }
export declare function Button(props: ButtonProps): React.ReactElement;
export interface CardProps { as?: string; tone?: 'default' | 'night'; flush?: boolean; className?: string; children?: React.ReactNode }
export declare function Card(props: CardProps): React.ReactElement;
export interface SectionLabelProps { children?: React.ReactNode }
export declare function SectionLabel(props: SectionLabelProps): React.ReactElement;
export interface PageHeaderProps { hero?: boolean; eyebrow?: string; title: string; subtitle?: string; actions?: React.ReactNode }
export declare function PageHeader(props: PageHeaderProps): React.ReactElement;
export interface TabsProps { items: { value: string; label: string; count?: number }[]; value?: string; defaultValue?: string; onChange?: (value: string) => void }
export declare function Tabs(props: TabsProps): React.ReactElement;
export interface PillProps { tone?: 'neutral' | 'ai'; children?: React.ReactNode }
export declare function Pill(props: PillProps): React.ReactElement;
export interface EnergyBadgeProps { energy: Energy; label?: string }
export declare function EnergyBadge(props: EnergyBadgeProps): React.ReactElement;
export interface StatusBadgeProps { status: 'now' | 'soon' | 'allocated' }
export declare function StatusBadge(props: StatusBadgeProps): React.ReactElement;
export interface RiskPillProps { level: 'high' | 'medium' | 'watch' | 'low' }
export declare function RiskPill(props: RiskPillProps): React.ReactElement;
export interface UtilPillProps { value: number; target?: number; label?: string }
export declare function UtilPill(props: UtilPillProps): React.ReactElement;
export interface AvatarProps { initials: string; energy: Energy; secondary?: Energy; size?: number; name?: string }
export declare function Avatar(props: AvatarProps): React.ReactElement;
export interface EnergyBarsProps { scores: Partial<Record<Energy, number>> }
export declare function EnergyBars(props: EnergyBarsProps): React.ReactElement;
export interface StatProps { tone?: 'default' | 'night'; label: string; value: React.ReactNode; note?: string }
export declare function Stat(props: StatProps): React.ReactElement;
export interface Person { name: string; initials: string; role: string; location: string; primary: Energy; secondary: Energy; wheelPosition: string; available: 'now' | 'soon' | 'allocated'; bio: string; scores: Partial<Record<Energy, number>>; utilisation: number; clients: number; revenue: string }
export interface PersonCardProps { person: Person }
export declare function PersonCard(props: PersonCardProps): React.ReactElement;
export interface TagProps { glass?: boolean; children?: React.ReactNode }
export declare function Tag(props: TagProps): React.ReactElement;
export interface HeadingProps { as?: string; size?: 'title' | 'hero'; muted?: string; children?: React.ReactNode }
export declare function Heading(props: HeadingProps): React.ReactElement;
export interface SplitButtonProps { lead: string; children?: React.ReactNode; onClick?: () => void }
export declare function SplitButton(props: SplitButtonProps): React.ReactElement;
export interface AssistantCardProps { name?: string; role?: string; question: string; hint?: string; suggestions?: string[]; placeholder?: string; next?: string; inputId?: string }
export declare function AssistantCard(props: AssistantCardProps): React.ReactElement;
export interface AuraHeroProps { links?: string[]; navCta?: string; eyebrow?: string; title: string; mutedLine?: string; subtitle?: string; cta?: { lead: string; label: string }; proof?: { people: [string, Energy, Energy][]; text: string }; assistant?: AssistantCardProps }
export declare function AuraHero(props: AuraHeroProps): React.ReactElement;
export interface BentoStatProps { tone?: 'light' | 'warm' | 'cool' | 'night'; value: string; sup?: string; caption: string; badge?: boolean }
export declare function BentoStat(props: BentoStatProps): React.ReactElement;
export interface Phase { when: string; title: string; text?: string; active?: boolean; progress?: { value: number; label: string }; items?: { label: string; done?: boolean }[] }
export interface PhaseCardsProps { phases: Phase[] }
export declare function PhaseCards(props: PhaseCardsProps): React.ReactElement;
export interface TopicCardProps { energy?: Energy; eyebrow?: string; title: string; text?: string }
export declare function TopicCard(props: TopicCardProps): React.ReactElement;
export interface FAQProps { items: { q: string; a: string }[]; defaultOpen?: number }
export declare function FAQ(props: FAQProps): React.ReactElement;
declare global { interface Window { Humyn: { Wordmark: typeof Wordmark; Button: typeof Button; Card: typeof Card; SectionLabel: typeof SectionLabel; PageHeader: typeof PageHeader; Tabs: typeof Tabs; Pill: typeof Pill; EnergyBadge: typeof EnergyBadge; StatusBadge: typeof StatusBadge; RiskPill: typeof RiskPill; UtilPill: typeof UtilPill; Avatar: typeof Avatar; EnergyBars: typeof EnergyBars; Stat: typeof Stat; PersonCard: typeof PersonCard; Tag: typeof Tag; Heading: typeof Heading; SplitButton: typeof SplitButton; AssistantCard: typeof AssistantCard; AuraHero: typeof AuraHero; BentoStat: typeof BentoStat; PhaseCards: typeof PhaseCards; TopicCard: typeof TopicCard; FAQ: typeof FAQ } } }
