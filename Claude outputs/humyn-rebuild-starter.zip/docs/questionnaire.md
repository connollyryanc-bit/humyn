# humyn Pulse Questionnaire v0.2

Nov 23, 2026 · @Ryan

## Purpose

The Pulse Questionnaire is humyn's own self-assessment: it gives every person their four energy scores in 12 to 15 minutes, and it is the yardstick the AI profile is checked against. All items are original to humyn and written for the Jungian-informed four-energy model; nothing is taken from Insights Discovery, DISC or any licensed instrument.

- **Source of truth.** A person's approved profile comes from their own answers. An AI profile drafted from a CV is a hypothesis until the questionnaire confirms it.
- **Validation tool.** Comparing AI drafts with questionnaire results, across many people, shows how far the AI can be trusted and where its prompt needs fixing.
- **Communication guide, not a test.** It describes how someone prefers to work and communicate. It is never used on its own to hire, fire, promote or rate anyone.
- **Draft status.** v0.2 needs review by a qualified work psychologist and a pilot study before the scores are presented as validated.

## Format

Two parts, 64 items, 12 to 15 minutes, one question per screen on mobile and desktop. The 32 items marked Lite also work on their own as **Pulse Lite**, a 6-minute version for retakes and colleague ratings.

| Part | Items | Answer format | Why |
| --- | --- | --- | --- |
| A. Statements | 40 (10 per energy, 2 reversed each) | 5-point scale: Not like me at all → Very like me | Measures each energy on its own |
| B. Forced-choice sets | 24 sets of four responses | Rank from most to least like you | Forces a choice, so people can't rate everything high; covers meetings, conflict, pressure, change, feedback and decisions |

- **Before starting**, the person sees what the questionnaire is for, who will see the result, and that they approve it before anyone else does.
- **At the end**, they see their scores, primary and secondary energy and wheel position at once, can retake it after 30 days, and choose whether to approve the profile.
- **Instructions**: "Answer for how you usually are at work, not how you'd like to be. There are no right answers."

## Part A: statements

Shown in a mixed order, never grouped by energy. R = reverse-scored (6 minus the answer). Lite = also in Pulse Lite.

| # | Statement | Energy | Key | Lite |
| --- | --- | --- | --- | --- |
| D1 | I make decisions quickly, even when I don't have all the information. | Driver | + | Lite |
| D2 | I would rather set the direction than follow someone else's plan. | Driver | + | Lite |
| D3 | I get impatient when a meeting ends without a decision. | Driver | + | Lite |
| D4 | I enjoy competing to win work or hit a target. | Driver | + | Lite |
| D5 | I say what I think directly, even when it may be unwelcome. | Driver | + | Lite |
| D6 | I prefer to let others take the lead on new projects. | Driver | R | Lite |
| D7 | I'm comfortable taking risks to move faster. | Driver | + |  |
| D8 | I like being measured on clear results. | Driver | + |  |
| D9 | I push back when I think a plan is too slow. | Driver | + |  |
| D10 | I find it hard to make a call until everyone agrees. | Driver | R |  |
| E1 | I get energy from brainstorming with a group. | Energizer | + | Lite |
| E2 | I find it easy to get people excited about an idea. | Energizer | + | Lite |
| E3 | I enjoy meeting new people at work. | Energizer | + | Lite |
| E4 | I shape my ideas by talking them through out loud. | Energizer | + | Lite |
| E5 | I bring humour and energy into a room. | Energizer | + | Lite |
| E6 | I prefer to work alone on most tasks. | Energizer | R | Lite |
| E7 | I enjoy presenting to a group. | Energizer | + |  |
| E8 | I get bored when work becomes routine. | Energizer | + |  |
| E9 | I easily start conversations with people I don't know. | Energizer | + |  |
| E10 | I keep my ideas to myself until they are finished. | Energizer | R |  |
| H1 | I notice quickly when someone in the team is unhappy. | Harmoniser | + | Lite |
| H2 | I make time to help colleagues, even when I'm busy. | Harmoniser | + | Lite |
| H3 | I look for a way forward that everyone can live with. | Harmoniser | + | Lite |
| H4 | I value a steady, predictable way of working. | Harmoniser | + | Lite |
| H5 | People come to me when they need someone to listen. | Harmoniser | + | Lite |
| H6 | I'm comfortable pushing a decision through when some people disagree. | Harmoniser | R | Lite |
| H7 | I adjust my own plans to help others succeed. | Harmoniser | + |  |
| H8 | Tension in a team stays with me after work. | Harmoniser | + |  |
| H9 | I stay loyal to the people I work with over the long term. | Harmoniser | + |  |
| H10 | I rarely think about how a decision will affect others. | Harmoniser | R |  |
| A1 | I check the details carefully before I share my work. | Analyst | + | Lite |
| A2 | I like to see the data before I form a view. | Analyst | + | Lite |
| A3 | I prefer a clear plan with defined steps. | Analyst | + | Lite |
| A4 | I keep asking questions until I fully understand a problem. | Analyst | + | Lite |
| A5 | I write things down to keep track of decisions and risks. | Analyst | + | Lite |
| A6 | I'm happy to start without a plan and work it out as I go. | Analyst | R | Lite |
| A7 | I enjoy working through a complex problem step by step. | Analyst | + |  |
| A8 | I like standards and processes to be clear and followed. | Analyst | + |  |
| A9 | I double-check numbers before they leave my hands. | Analyst | + |  |
| A10 | I trust my gut more than the evidence. | Analyst | R |  |

## Part B: forced-choice sets

The person ranks the four responses from most like them (3 points) to least like them (0 points). The four options appear in a different random order each time; the energy labels are never shown. Sets S1–S8 are also in Pulse Lite.

| # | Situation | Driver response | Energizer response | Harmoniser response | Analyst response |
| --- | --- | --- | --- | --- | --- |
| S1 | A new brief lands on Friday afternoon. First you… | set a goal and name an owner | call the team together to bounce ideas | check who has time and how people are feeling | read it closely and list the open questions |
| S2 | A project is running late. You… | cut scope and push for a decision | rally the team for a fresh push | ask each person what is blocking them | rebuild the plan around the critical path |
| S3 | You need to give a colleague critical feedback. You… | keep it short and direct | frame it positively and talk it through | do it privately and offer support | bring specific examples and evidence |
| S4 | In a workshop you are most likely to… | drive the group to decisions | come up with ideas | make sure everyone is heard | capture and structure what is said |
| S5 | What drains you most at work? | slow decisions | working in isolation | conflict in the team | careless work |
| S6 | You prefer a request to come… | with the bottom line first | as a quick chat | with the why and who it affects | in writing, with the details |
| S7 | In your first month in a new role you… | look for quick wins | meet as many people as possible | build trust with your team | learn the systems and processes |
| S8 | Under pressure you tend to… | take control | talk it through with others | go quiet and keep the peace | double-check everything |
| S9 | Two colleagues disagree in a meeting. You… | ask them to agree a decision now | lighten the mood and look for a new angle | help each side hear the other | ask what evidence each of them has |
| S10 | A big reorganisation is announced. First you… | look for the opportunity in it | talk it over with colleagues | think about how your team will feel | read exactly what changes |
| S11 | The praise you value most… | names the result you achieved | is given in front of others | is personal and sincere | is specific about what you did well |
| S12 | You have to choose between two suppliers. You… | pick quickly and move on | go with the one you clicked with | choose the one your team prefers | compare them against clear criteria |
| S13 | A client is unhappy. You… | take ownership and fix it fast | call them and rebuild the relationship | listen carefully and reassure them | find out exactly what went wrong |
| S14 | At the start of a project you most want… | a clear goal and the authority to act | an inspiring vision | a team that works well together | a detailed plan |
| S15 | Your ideal working week has… | ambitious targets | plenty of time with people | a steady rhythm | time to focus deeply |
| S16 | When you are stuck on a problem you… | try something and adjust | ask others for ideas | turn to someone you trust | research it thoroughly |
| S17 | Your emails are usually… | a few lines long | warm and casual | carefully checked for tone | complete with all the details |
| S18 | A deadline moves forward a week. You… | reprioritise straight away | rally people to help | check the team can cope | re-plan what is realistic |
| S19 | Someone challenges your idea in front of others. You… | defend it firmly | turn it into a lively discussion | look for common ground | ask for their reasoning |
| S20 | You are asked to lead something new. Your first thought is… | I'll take charge | who can I bring in? | is the team right for this? | what exactly is involved? |
| S21 | In a team you are often the one who… | keeps things moving | keeps the energy up | keeps people together | keeps things accurate |
| S22 | A colleague misses a deadline. You… | tell them plainly it can't happen again | keep it light and agree a new date | ask whether everything is okay | look at what caused the delay |
| S23 | You learn a new tool best by… | diving in and using it | learning it with others | being shown by someone patient | reading the guide first |
| S24 | A good day at work is one where… | you got things done | you connected with people | the team worked well together | the work was right |

## Scoring

Each energy gets a score from 0 to 100, blending the statements (60%) and the scenarios (40%). The weights are a starting point to be tuned in the pilot.

1. **Part A.** Add the ten answers for the energy (reversed item = 6 minus the answer). The total runs 10–50. Part A score = (total − 10) ÷ 40 × 100. Pulse Lite uses its six items: total 6–30, score = (total − 6) ÷ 24 × 100.
2. **Part B.** Add the points that energy's responses earned across the 24 sets. The total runs 0–72. Part B score = total ÷ 72 × 100. Pulse Lite uses sets S1–S8: total 0–24, score = total ÷ 24 × 100.
3. **Energy score** = 0.6 × Part A + 0.4 × Part B, rounded to a whole number.
4. **Primary energy** = the highest score. A tie goes to the higher Part B score; if still tied, the person picks.
5. **Secondary energy** = the higher of the primary's two neighbours on the wheel. Driver sits between Analyst and Energizer, Energizer between Driver and Harmoniser, Harmoniser between Energizer and Analyst, Analyst between Harmoniser and Driver.
6. **Wheel position.** If the primary is more than 15 points above the secondary, the position is the primary alone ("Driver"). Otherwise it is the secondary's adjective plus the primary: Driving, Energizing, Harmonising or Analytical ("Energizing Driver", "Harmonising Analyst").

**Worked example.** Astrid scores Driver 86, Energizer 71, Harmoniser 32, Analyst 44. Her primary is Driver. Its neighbours are Energizer (71) and Analyst (44), so her secondary is Energizer. The gap is 15, not more than 15, so her position is Energizing Driver. With Driver at 90 she would be a pure Driver. The pilot checks whether 15 is the right threshold.

## Checking the AI profile

The AI never has the last word: its draft is compared with the person's own questionnaire, and the questionnaire wins.

1. **AI draft.** With consent, the AI reads a CV the person uploads and estimates the same four scores (0–100), a primary and secondary, and a confidence level. The person sees it labelled "AI draft".
2. **Questionnaire.** The person completes the full 64 items (or Pulse Lite). Their scores replace the AI draft.
3. **Comparison, stored for validation only.** For each person: whether the primary energy matches, the difference on each energy, and the overall gap (the average of the four differences).
4. **Disagreement.** If the primary energy differs, or any energy differs by more than 25 points, the AI result is flagged for review and its reasoning is logged for prompt improvement. The person only ever sees their questionnaire result.
5. **Over time.** The match rate across all people is tracked per AI prompt and model version. AI drafting can only be offered as a shortcut once it meets the targets below.

## Validation plan

A pilot of at least 200 people across 3 to 5 companies, run with a qualified work psychologist, decides whether v0.1 holds up. The EFPA test review model is a good checklist for the evidence a buyer or reviewer will expect. Targets below are the bar for calling the questionnaire validated.

| Check | How | Target |
| --- | --- | --- |
| Item quality | Each item's correlation with the rest of its energy | 0.30 or higher; weaker items rewritten |
| Internal consistency | Cronbach's alpha (or omega) per energy | 0.70 or higher |
| Four-energy structure | Factor analysis of Part A | Items load on their own energy at 0.40 or higher |
| Stability | Same people retake it after 4–6 weeks | Scores correlate 0.70 or higher; same primary for 75% or more |
| Fit with an established model | Compare with the free, public-domain IPIP Big Five | Expected links, each 0.30 or higher: Energizer with Extraversion, Harmoniser with Agreeableness, Analyst with Conscientiousness, Driver with assertiveness |
| Others see it too | Two colleagues rate the person on a short version | Same primary energy for 60% or more |
| Fairness | Compare results by gender, age band and language, only where people consented to share these | No item behaves differently for a group once energy is accounted for |
| AI vs questionnaire | Comparison from the section above | Same primary for 70% or more; average gap 15 points or less |
| Recognition | "This describes me well" after seeing results | Average 4 out of 5 or higher |

Translate into Swedish, Danish and Norwegian with back-translation before the Nordic pilot, and test each language version separately.

## Ethics and compliance

- **Voluntary.** Nobody is required to take it, and declining has no consequence for staffing, pay or review.
- **Consent first,** recorded per purpose: taking the questionnaire, AI drafting from a CV, and sharing the result with the team.
- **The person sees it first** and approves it before anyone else can; they can retake it, correct it or delete it.
- **No high-stakes use on its own.** Never the sole basis for hiring, firing, promotion, pay or performance ratings. The product never ranks people by energy.
- **No emotion or health inference.** Items ask about work preferences only; nothing about mood, stress, mental health or private life.
- **Honest claims.** Until the validation targets are met, it is described as a communication-style guide, not a validated psychometric test.
- **Data kept minimal.** Raw answers are visible to the person and stored in the EU; the comparison data used for validation is pseudonymised.

## Open questions

- [ ] Find a work psychologist to review the items and lead the pilot
- [ ] Pick 3 to 5 pilot companies and agree consent wording with them
- [ ] Decide whether managers see energy scores or only the wheel position
- [ ] Confirm the 60/40 weighting and the 15-point threshold after the pilot
- [ ] Check that Pulse Lite gives the same primary energy as the full version for 85% or more of pilot participants
- [ ] Commission Swedish, Danish and Norwegian translations
