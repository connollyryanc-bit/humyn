# humyn — Rebuild Spec v1

Nov 23, 2026 · @Ryan

## Purpose and ground rules

This spec rebuilds humyn from scratch as Ryan's own product: a multi-company SaaS on the approved humyn design system, starting with humyn Teams. Nothing is carried over from the old repository except the product thinking.

- **Clean room.** New repository. Claude Code never reads, copies or migrates code from the old Humyn repo. It builds only from this spec and the design system.
- **Own accounts.** GitHub, Vercel, Supabase, Anthropic API and domain all sit under Ryan's company (AB to be formed), on personal hardware.
- **Timing.** Cleared. Ryan's last Valtech day was 13 Nov 2026 under a signed release, so product code can start now. Keep the signed release with the company papers for investor due diligence.
- **No Valtech material.** No Valtech fonts, colours, staff names, client names, rates or utilisation figures. All sample data is invented and marked as sample.
- **Old repo stays untouched.** Archive it; don't delete it or rewrite its history.
- **Own model.** The four-energy model is described as Jungian-informed. No Insights Discovery names, materials or questionnaire, ever.

## Scope of v1

v1 is humyn Teams, good enough to pilot with one or two agencies: people, profiles with consent, team building, bench and capacity, and an executive view. Reach and Careers come later on the same engine.

| Area | In v1 | Later |
| --- | --- | --- |
| Accounts | Company sign-up, invite by email, roles (Admin, Exec, Capacity manager, Manager, Member) | SSO, SCIM |
| People | Directory (cards and table), search, filters, group by energy / market / availability | HRIS import |
| Profiles | Self-assessment questionnaire, person approves and can correct their profile, AI-written guidance from the approved result | AI drafting from a CV, only with the person's consent |
| Personal guidance | How to work with me, drivers, drains, how to speak and email | Coaching between two people |
| Messaging | Write once, rewrite per person's energy (copy to clipboard, no sending) | Sending through Gmail or Outlook |
| Teams | Team builder with energy balance and gap warnings, team kickoff brief | Interview panel balancing |
| Capacity | Utilisation vs target, bench list, availability, skills and seniority | Live sync from ERP or OpenAir |
| Executive | Bench value, experience on the bench, team balance by market, scenario: "what we lose if these people go" | Revenue leakage, M&A culture check |
| Assistant | Ask humyn on the dashboard: answers from the company's own data | Meeting prep briefs |
| Out of v1 | LinkedIn scraping, prospect profiling, cold outreach, job search | Reach and Careers modules |

## Architecture and stack

A standard, hand-off-friendly stack: Next.js and TypeScript on Vercel, Supabase for the database and login, and Claude for AI, all in EU regions.

```
Browser (Next.js app)  ->  Server (Vercel, EU)  ->  Supabase (EU): Postgres + row-level security, auth, storage
humyn design system        API routes, server       
no keys, no AI calls       actions; checks role  ->  Anthropic API: profile guidance, rewrites, Ask humyn
                           and org_id; writes        (server-side only, no training on customer data)
                           every view to audit_log
```

The browser never talks to the database or the AI directly: the server checks the user's company and role, applies row-level security, and logs access. TypeScript runs in strict mode, so a developer can take the code over later.

## Data model

Every table except `organisations` carries `org_id`, and row-level security means a user only ever sees rows from their own company.

| Table | Holds | Notes |
| --- | --- | --- |
| organisations | Company name, markets, utilisation target, plan | One per customer |
| members | Login user, role, org | Links Supabase auth to an org |
| people | Name, role, market, office, seniority, years of experience, skills, day rate band | A person can exist before they log in |
| consents | Person, purpose, granted / withdrawn, timestamp | One row per purpose: profiling, AI guidance, sharing with team |
| assessments | Questionnaire answers, version, completed at | Raw answers, visible to the person |
| profiles | Energy scores, primary, secondary, wheel position, status (draft / approved), source (self / AI-assisted), version | Only approved profiles are shown to others |
| guidance | AI-written drivers, drains, how to speak, how to email, model and prompt version | Regenerated when the profile changes |
| allocations | Person, brief, % allocated, start, end | Drives utilisation and bench |
| briefs | Client, market, stage, start, required energies and skills | The staffing pipeline |
| teams | Brief, members, balance score, kickoff brief | Team builder output |
| audit\_log | Who saw or changed what, when, and why | Required for AI Act and GDPR |

## Compliance built in

The rule is consent first, visible to the person, and a human decides. These are product features, not a later clean-up, and they are a selling point to HR directors. Validate with an EU/Nordic data protection lawyer before the first pilot.

- **Self-assessment first.** A person's profile starts from their own questionnaire, never from scraping. AI may only draft from a CV the person uploads themselves, with explicit consent.
- **The person sees it first.** Profiles start as drafts. Only the person can approve one; they can correct it, withdraw consent or delete it at any time, and others then stop seeing it.
- **Advice, not verdicts.** Every profile and AI output is labelled as guidance. No screen recommends firing, rates performance, or ranks people by personality.
- **A human decides.** Scenario tools show impact (experience, capacity, balance) but never pick names. Every decision screen says so.
- **No emotion inference.** Never infer mood, stress or emotion from text, voice or behaviour. This is banned at work under the EU AI Act.
- **Audit trail.** Every view of a profile by someone else, every export and every AI generation is logged.
- **Data rights.** Export my data and delete my data are self-serve.
- **EU only.** Database and hosting in EU regions; AI calls with no training on customer data.
- **Paperwork.** DPIA template, data processing agreement, privacy notice and AI Act high-risk documentation prepared before selling.

## Design system rules

The approved [humyn Design System](../design-system/README.md) is the only source of visual truth; the app never styles an element by hand. It lives in `design-system/` in this repo.

- **Tokens in one file.** Export the design system's `tokens.json` to `styles/tokens.css` as CSS variables. No hex values, font sizes or radii anywhere else in the code.
- **Components in one folder.** Port every design system component to `components/ui/` as typed React components with the same names and props: Wordmark, Button, SplitButton, Card, Tag, Heading, PageHeader, AuraHero, Tabs, Pill, EnergyBadge, StatusBadge, RiskPill, UtilPill, Avatar, EnergyBars, Stat, BentoStat, PersonCard, AssistantCard, PhaseCards, TopicCard, FAQ.
- **Pages compose, never restyle.** A page imports from `components/ui/`. A new pattern becomes a component first.
- **Still to design before they are built:** the full energy ring, dynamics and spider charts; data tables; forms and inputs; the drawer; the nav bar; empty and loading states; an icon set.
- **Colour rules.** No traffic-light colours anywhere. Energies use the four logo wing colours and only ever mean personality. Status uses navy, outline and the brand gradient, always with a word.
- **Type.** Manrope only, loaded with `next/font/google`.
- **Both themes.** Light by default, dark through the same tokens; every text pair at least 4.5:1.

**Decided since v1**

- **Clean look.** White page, 120px between sections, one hero moment and one main action per screen, content unboxed with hairline dividers. Match the [key screens](../mockups/README.md): Overview, People and Profile, plus the navigation.
- **Energy names.** Driver, Energizer, Harmoniser, Analyst, in the logo's four wing colours.
- **Logo mark.** App icon, browser tab, Chrome extension, sign-in and onboarding, and as the face of Ask humyn. Never in the top nav; the wordmark carries it. Small-size and single-colour versions are still to come.

## Build phases

Six phases, each finished only when its checks pass. Each phase is one Claude Code session or a few, ending with a deploy to a preview URL.

1. **Foundations.** New repo, Next.js, Supabase (EU), tokens.css, Manrope, all design system components in `components/ui/`, a `/design` page showing every component.
   - Done when: the `/design` page matches `design-system/` (README, component previews and tokens) in light and dark, and there are no hard-coded colours (a lint rule checks this).
2. **Accounts and roles.** Company sign-up, invites, five roles, row-level security on every table, audit log.
   - Done when: a user in company A cannot read any row from company B (automated test), and every role sees only its pages.
3. **People and profiles.** Directory, person pages, the [Pulse Questionnaire](questionnaire.md) with its scoring, draft → approve flow, consent screens, AI guidance from approved profiles, export and delete.
   - Done when: a new member can complete the questionnaire, approve their profile and see it in the directory, all in under 10 minutes; withdrawing consent hides the profile at once.
4. **Teams and capacity.** Allocations, utilisation vs target, bench, briefs, team builder with balance and gap warnings, kickoff brief, message rewrite.
   - Done when: a capacity manager can staff a brief from the bench and get a kickoff brief for the team.
5. **Executive and assistant.** AuraHero dashboard, bench value, experience on the bench, balance by market, the "what we lose" scenario, Ask humyn over the company's data.
   - Done when: the scenario shows experience and capacity lost, with no names recommended, and the assistant answers only from the org's own rows.
6. **Pilot readiness.** Sample company with invented data, onboarding flow, privacy notice, DPA, DPIA, error tracking, backups.
   - Done when: a pilot customer can be onboarded without Ryan touching the database.

## Claude Code kickoff

See `KICKOFF.md` and `CLAUDE.md` in the repo root; the versions below are kept for reference.

**Kickoff prompt**

```
We are building humyn from scratch: a multi-company people intelligence SaaS. This is a new, empty repository. Do not look for, read or copy any other Humyn codebase.

Read the rebuild spec and the design system README and tokens I've attached. Then do Phase 1 only (Foundations):
- Next.js (App Router), TypeScript strict, Supabase client set up for an EU project.
- Turn tokens.json into styles/tokens.css (light and dark).
- Load Manrope with next/font/google.
- Build every design system component in components/ui/ with typed props, matching the design system exactly.
- Add a /design page that shows every component in light and dark.
- Add a lint rule that fails on hex colours outside styles/tokens.css.
Write CLAUDE.md from the spec. Stop after Phase 1 and show me the /design page.
```

**CLAUDE.md (starting point)**

```markdown
# humyn
People intelligence SaaS. Multi-company: every table has org_id and row-level security.

## Rules
- Build only from the rebuild spec and the humyn design system. Never use code from any older Humyn repo.
- Style only through components/ui and styles/tokens.css. No hex values, inline colours or one-off font sizes in pages.
- A new UI pattern becomes a component in components/ui first.
- Energies: Driver, Energizer, Harmoniser, Analyst (wheel adjectives: Driving, Energizing, Harmonising, Analytical). Never colour names in the UI, never Insights Discovery terms.
- No traffic-light colours. Status = navy, outline, brand gradient, always with a word.
- Profiles start as drafts; only the person approves. Only approved profiles are shown to others.
- Never infer emotion or mood. Never recommend who to fire or rank people by personality.
- Log every profile view by someone else, every export and every AI generation to audit_log.
- AI calls are server-side only; keys never reach the browser.
- Sample data is invented and labelled as sample.
```

## Open decisions

- [x] Rename Supporter: now Harmoniser
- [x] Draft humyn's own questionnaire: [Pulse Questionnaire v0.2 (64 items, plus a 32-item Lite version)](questionnaire.md)
- [x] Clear the Valtech IP question: signed release, last day 13 Nov 2026
- [x] Set the start date for product code: now
- [ ] Form the AB and assign the humyn IP to it
- [ ] Trademark search for "humyn" and the logo in the EU and Sweden
- [ ] Draw small-size (16–32px) and single-colour versions of the logo
- [ ] Choose an icon set
- [ ] Find a work psychologist to review and pilot the questionnaire
- [ ] Pick one or two pilot agencies and a pilot price
- [ ] Data protection lawyer review of the compliance plan before the first pilot
