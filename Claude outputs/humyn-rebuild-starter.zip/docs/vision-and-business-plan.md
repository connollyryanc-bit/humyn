# Humyn — Vision, Business Plan & Legal Setup

Draft v1. Working document to feed the seed deck.

## Vision

Humyn turns the human side of a business into something leaders can see, measure and act on. In a world where AI shrinks teams, knowing who you have and how they work together becomes a competitive advantage.

One line: **People intelligence for the AI era. Know who you have, who you're selling to, and where you fit.**

## The problem

- **Layoffs are made on spreadsheets.** Restructures draw red lines through high-cost centres without seeing the experience, capability depth or leadership being lost.
- **Capability is understood, but depth isn't.** Leaders know what skills they need to sell a service, not how deep the skill and seniority behind them go.
- **Capacity is a blind spot.** Who is utilised, on what, who is on the bench, and what happens if those people leave?
- **Teams are staffed by availability, not fit.** The best delivery comes from the right mix of personalities, not whoever is free. An all-detail team stalls, and an all-driver team rushes and drops things.
- **Cuts and biased hiring unbalance a business.** Cutting senior people and hiring in the hiring manager's image leaves organisations junior-heavy and one-dimensional.
- **Firing one to save three is riskier with AI.** Broad, T-shaped senior generalists are exactly who drives a smaller, AI-augmented business.

Founder insight: Ryan has led transformation and delivery at executive level and has been on the receiving end of a mass layoff.

## The solution

One shared profiling engine, built on a four-colour personality model (drivers, communication style, working preferences), combined with capability, seniority and capacity data. Separate modules sit on top of it.

### Humyn for Teams (HR, ops, C-suite) — lead product, most built

- Profiles of staff, teams, offices and the whole organisation
- Capability depth, seniority and experience alongside cost
- Bench and utilisation view: the value of the bench in money, experience and personality
- What motivates each person to get off the bench
- Team composition: build the best mix for each brief
- Messages rewritten to suit each person's profile, one to one or one to many
- Executive dashboard by market, region and office
- Scenario view: what you lose if these people go

### Humyn for Sales (commercial directors, account execs, BDMs)

- Prospect discovery by industry, capability and title
- Prospect profiles and tips on how to approach each one
- Write one email and get it rewritten for each prospect's profile
- Outreach flows, templated or custom: LinkedIn step, email, wait, branch on reply
- Tracking and CRM integration
- Example: pharma reps tailoring follow-ups to doctors

### Humyn for Careers (job seekers)

- Profile yourself from your CV or LinkedIn
- Job matching across job boards by personality and capabilities
- One-click tailored CVs per job, written to read well in hiring systems
- Tips for each hiring manager, taken from how the job ad is written
- Application pipeline: kanban, follow-ups, calendar link

### How the modules connect

- **Teams to Careers:** companies running layoffs buy Careers seats for leavers as outplacement. The HR sale feeds Careers users.
- **Sales:** the same engine pointed outward at clients.

## Business model

- **One brand, one engine, separately priced modules.** Modules can be bundled for enterprise and kept separable for a future spin-off or sale.
- **Teams:** enterprise SaaS, priced per employee or per organisation, with onboarding and setup services.
- **Sales:** per-seat SaaS, competing with Crystal Knows, Apollo, Lemlist and similar.
- **Careers:** low-cost consumer subscription, plus B2B outplacement packages.
- **Go-to-market:** lead with Teams in Scandinavia and the UK through agency and consulting networks, where the pain is current.

## Roadmap

1. **Now:** finish Teams, design system, consent-first profiling, pilot with one or two agencies
2. **Next:** Careers (easiest legally) plus outplacement bundles
3. **Then:** Sales with compliant outreach flows and CRM integrations
4. **Later:** M&A culture checks — map both organisations before a deal to find culture clashes and key people at risk

### Feature backlog

- Team kickoff briefs
- Manager onboarding guides
- Interview panel balancing
- Meeting prep briefs linked to calendar
- Coaching and conflict tool for pairs

### Other opportunities

- Customer service agent-to-customer matching
- Investor profiling for fundraising
- Sports and education team balancing
- Hospitality guest messaging (test on Host Harmony)

## Legal and compliance setup

*Not legal advice. Validate with an EU/Nordic data protection lawyer.*

### Rules that apply

- **EU AI Act:** AI used for hiring, firing, promotion, task allocation or monitoring workers is high-risk. That brings risk management, documentation, human oversight and transparency duties. Emotion recognition at work is prohibited, so never infer mood or emotion. High-risk deadlines have shifted, so confirm the current dates.
- **GDPR:** profiling needs a lawful basis. When data isn't collected from the person, they must be informed. Employee consent is rarely valid because of the power imbalance. No solely automated decisions with significant effects. A data protection impact assessment (DPIA) is required.
- **Email marketing:** rules vary by country. Denmark generally requires prior consent, even for B2B.
- **Pharma:** industry codes on contacting healthcare professionals apply.
- **LinkedIn:** terms ban scraping and automation, with real account-ban and legal risk.
- **Insights Discovery:** a trademarked, licensed model. License it or build our own four-colour framework.

### How we design around it

- **Principle:** consent first, visible to the person, and a human decides.
- **Teams:** employees complete their own assessment, can see and correct their profile, and get value back. Profiles are advisory only. No covert LinkedIn profiling of staff. Full audit trail and human sign-off on any decision.
- **Sales:** only use information prospects have published themselves. Show insights as private coaching tips, not stored dossiers. Say how you found them, with an easy opt-out. Every LinkedIn action is a real user click, with clear account-risk warnings. Automation runs on email and CRM, with country-aware consent rules.
- **Careers:** self-profiling, with clear data use and full delete. Hiring manager tips come from the job ad, not personal profiling.
- **Positioning:** compliance is a selling point to HR directors.

## Seed deck outline

1. **Title:** Humyn — people intelligence for the AI era
2. **Problem:** layoffs by spreadsheet, invisible experience loss, teams staffed by availability
3. **Why now:** AI is shrinking teams, mass restructures, EU AI Act raising the bar
4. **Solution:** one engine, three modules
5. **Product:** Teams demo (dashboard, bench, team mix)
6. **How it connects:** Teams to outplacement to Careers, and Sales
7. **Market:** HR tech, sales intelligence, careers (sizing to be researched)
8. **Business model:** enterprise SaaS, seats, consumer, outplacement
9. **Competition:** Crystal Knows, workforce planning tools, ATS and CV tools. Our edge: people, capability and capacity in one place, compliance-first
10. **Go-to-market:** Nordics and UK, agencies and consultancies first
11. **Traction:** build status, pilots
12. **Roadmap:** Teams, Careers, Sales, M&A
13. **Team:** founder story and experience
14. **The ask:** seed amount and use of funds
