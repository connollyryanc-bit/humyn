# Key screens (approved look)

These are the approved mockups for humyn Teams. Match their layout, spacing, copy tone and hierarchy. They are reference designs, not code to copy.

| File | Screen | Notes |
| --- | --- | --- |
| `Nav.dc.html` | Top navigation (shared) | Wordmark + small module switcher ("Teams ▾"), five text links with an underline on the active one, search icon, "Ask humyn", avatar. White, hairline bottom border. |
| `Main.dc.html` | Executive overview | One aura hero (greeting + one line + one SplitButton), three unboxed Stats, "Oslo is short of Drivers" with market energy bars, the bench as a divided list, an outlined scenario card. |
| `People.dc.html` | People directory | Big two-tone title, one primary action, underline Tabs + search + group, energy counts as a line of dots, a quiet divided list (avatar, wheel position, market, availability, utilised). |
| `Profile.dc.html` | Person profile | Large name and avatar, one line of facts, one primary action, underline Tabs, two calm columns (energy bars / how to work with them), one soft grey "Write it once" panel, consent line. |

## How to read the files

They use a small template format from the design tool:

- `<x-import component-from-global-scope="Humyn.Button" variant="primary">Invite people</x-import>` means: use the `Button` component from `design-system/` with these props.
- `<dc-import name="Nav" active="people">` means: include the Nav screen with `active="people"`.
- `<sc-for list="{{ people }}" as="p">` repeats its contents for each item; `{{ p.name }}` is a value. The data comes from the `renderVals()` function at the bottom of each file.
- Plain `<div style="…">` markup is layout: copy the structure and spacing, but express colours, type and radii through `styles/tokens.css` variables and `components/ui`, never as hard-coded values.

All people and figures are invented sample data.

## Rules the screens follow

- White page, content max 1200px, 120px between sections.
- One hero moment (aura) per screen at most, and only on the Overview.
- One primary action per screen.
- Content sits on white with hairline dividers; cards only for things you can pick up.
- No traffic-light colours. Energy colours only mean personality.
